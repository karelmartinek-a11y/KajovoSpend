Set-Location  C:/github/KajovoSpend
 =  src/kajovospend/ui/main_window.py
 = Get-Content  -Raw -Encoding utf8
