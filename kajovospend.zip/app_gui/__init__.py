# Package entrypoint for GUI
from .py import main
